package com.xrquest.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
        }
        root.addView(TextView(this).apply { text = "XR Quest"; textSize = 32f; gravity = Gravity.CENTER })
        root.addView(Button(this).apply {
            text = "Jogar"
            setOnClickListener { startActivity(Intent(this@MainActivity, GameActivity::class.java)) }
        })
        root.addView(Button(this).apply {
            text = "Configurações"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        setContentView(root)
    }
}
