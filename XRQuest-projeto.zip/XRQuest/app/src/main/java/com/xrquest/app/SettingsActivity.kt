package com.xrquest.app

import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.*
import rikka.shizuku.Shizuku

class SettingsActivity : Activity() {
    private lateinit var box: LinearLayout
    private val sp by lazy { getSharedPreferences("xr", 0) }
    private var inMenu = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48) }
        setContentView(ScrollView(this).apply { addView(box) })
        showMenu()
    }

    override fun onBackPressed() { if (inMenu) super.onBackPressed() else showMenu() }

    private fun title(t: String) = box.addView(TextView(this).apply { text = t; textSize = 22f; setPadding(0, 0, 0, 24) })
    private fun label(t: String) = box.addView(TextView(this).apply { text = t; setPadding(0, 24, 0, 8) })

    private fun showMenu() {
        inMenu = true; box.removeAllViews(); title("Configurações")
        val cats = listOf("1. Shizuku", "2. Tracking e gráficos", "3. Loja e luva", "4. Câmera e conforto", "5. Em breve")
        cats.forEachIndexed { i, n -> box.addView(Button(this).apply { text = n; setOnClickListener { show(i + 1) } }) }
    }

    private fun show(n: Int) {
        inMenu = false; box.removeAllViews()
        when (n) {
            1 -> shizuku()
            2 -> tracking()
            3 -> loja()
            4 -> conforto()
            else -> { title("Categoria 5"); label("Em breve.") }
        }
    }

    private fun slider(text: String, key: String, min: Int, max: Int, def: Int) {
        val tv = TextView(this); box.addView(tv)
        val cur = sp.getInt(key, def)
        tv.text = "$text: $cur"
        box.addView(SeekBar(this).apply {
            this.max = max - min; progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    sp.edit().putInt(key, p + min).apply(); tv.text = "$text: ${p + min}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun toggle(text: String, key: String, def: Boolean) = box.addView(Switch(this).apply {
        this.text = text; isChecked = sp.getBoolean(key, def)
        setOnCheckedChangeListener { _, v -> sp.edit().putBoolean(key, v).apply() }
    })

    private fun shizuku() {
        title("Shizuku")
        val running = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        val granted = running && try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
        label("Shizuku rodando: ${if (running) "SIM" else "NÃO"}")
        label("Permissão concedida: ${if (granted) "SIM" else "NÃO"}")
        if (running && !granted) box.addView(Button(this).apply {
            text = "Pedir permissão"
            setOnClickListener { try { Shizuku.requestPermission(1) } catch (e: Throwable) {} }
        })
        box.addView(Button(this).apply {
            text = "Abrir Shizuku"
            setOnClickListener {
                packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
                    ?: Toast.makeText(this@SettingsActivity, "Shizuku não instalado", Toast.LENGTH_SHORT).show()
            }
        })
        label("Código de pareamento (digitado na notificação de Depuração sem fio)")
        box.addView(EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER; hint = "000000"
            setText(sp.getString("pair_code", ""))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { sp.edit().putString("pair_code", s.toString()).apply() }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        })
    }

    private fun tracking() {
        title("Tracking e gráficos")
        slider("Hz do hand tracking", "hz", 15, 120, 60)
        toggle("Sombras no mundo 3D", "shadow", true)
    }

    private fun loja() {
        title("Loja e luva")
        label("Jogos disponíveis para baixar: (em breve)")
        label("Cor da luva")
        val cores = listOf("Azul" to Color.BLUE, "Vermelho" to Color.RED, "Verde" to Color.GREEN, "Roxo" to Color.MAGENTA)
        val row = LinearLayout(this); box.addView(row)
        cores.forEach { (n, c) -> row.addView(Button(this).apply {
            text = n; setTextColor(c); setOnClickListener { sp.edit().putInt("glove_color", c).apply() }
        }) }
        label("Desenhar a luva: (em breve)")
    }

    private fun conforto() {
        title("Câmera e conforto")
        slider("IPD (mm)", "ipd", 50, 75, 63)
        slider("Campo de visão (°)", "fov", 60, 120, 90)
        slider("Limite de FPS (0 = sem limite)", "fps_limit", 0, 144, 0)
        toggle("Modo cardboard", "cardboard", false)
        toggle("Modo economia", "eco", false)
    }
}
