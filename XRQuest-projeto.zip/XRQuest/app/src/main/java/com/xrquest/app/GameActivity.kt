package com.xrquest.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView

// Placeholder: aqui entram câmera + MediaPipe (3 IAs), render estéreo/cardboard e luva 3D.
class GameActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("xr", 0)
        setContentView(TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 18f
            text = "Mundo 3D (em desenvolvimento)\n" +
                "Hz tracking: ${sp.getInt("hz", 60)} | Sombras: ${sp.getBoolean("shadow", true)}\n" +
                "Cardboard: ${sp.getBoolean("cardboard", false)}"
        })
    }
}
